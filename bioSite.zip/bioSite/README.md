A bioSite about the creator's best friend, Leann Nguyen, created in 2024.
 

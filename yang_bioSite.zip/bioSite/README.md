<h1>CSD 340 Web Development with HTML and CSS</h1>
<h2>Contributers</h2>
<ul>
  <li>Alexis Yang</li>
  <li>Prof. Joseph Issa</li>
</ul>
